from datetime import datetime, timedelta
import calendar

def get_option_expiration_date(year, month):
    """
    Calculates the options expiration date for a given month and year.

    If the 3rd Friday is a holiday, it returns the Thursday before it.

    Args:
        year: The year (e.g., 2025).
        month: The month (e.g., 1 for January, 12 for December).

    Returns:
        A datetime.date object representing the options expiration date.
    """

    # Calculate the 3rd Friday of the month
    third_friday_date = get_third_friday(year, month)

    # Check if the 3rd Friday is a holiday (replace with your actual holiday checking logic)
    if is_holiday(third_friday_date):
        # If it is a holiday, return the Thursday before
        return third_friday_date - timedelta(days=1)
    else:
        return third_friday_date

def get_third_friday(year, month):
    """
    Calculates the date of the 3rd Friday of a given month.

    Args:
        year: The year.
        month: The month.

    Returns:
        A datetime.date object representing the 3rd Friday.
    """

    # Get the first day of the month
    first_day = datetime(year, month, 1).date()

    # Find the first Friday of the month
    first_friday = first_day + timedelta((4 - first_day.weekday()) % 7)

    # Calculate the 3rd Friday
    third_friday = first_friday + timedelta(weeks=2)
    return third_friday

def is_holiday(date):
    """
    Checks if a given date is a trading holiday.

    Args:
        date: A datetime.date object.

    Returns:
        True if the date is a holiday, False otherwise.
    """
    # Replace this with your actual holiday checking logic.
    # This example assumes a specific list of holidays.
    holidays = [
        datetime(2025, 1, 1).date(),  # New Year's Day
        datetime(2025, 7, 4).date(),  # Independence Day
        datetime(2025, 9, 1).date(),  # Labor Day
        datetime(2025, 11, 27).date(),  # Thanksgiving
        datetime(2025, 12, 25).date()   # Christmas Day
    ]

    return date in holidays

# Example usage:
year = 2025
month = 6  # June

expiration_date = get_option_expiration_date(year, month)
print(f"The options expiration date for June {year} is: {expiration_date}")
