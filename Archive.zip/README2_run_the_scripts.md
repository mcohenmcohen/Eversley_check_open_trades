How to run the scripts

ETFs:
- python currency_strategy_backtester.py --mode etfs --debug

Futures:
- python currency_strategy_backtester.py --mode futures --debug
